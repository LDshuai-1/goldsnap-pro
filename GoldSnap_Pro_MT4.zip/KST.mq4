//+------------------------------------------------------------------+
//| KST.mq4                                                           |
//| Know Sure Thing - 多周期ROC加权平滑, 确认趋势转折                    |
//| 用法: KST>信号线=多头, KST<信号线=空头, 零轴穿越=大趋势              |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_separate_window
#property indicator_buffers 2
#property indicator_color1 clrDodgerBlue
#property indicator_color2 clrTomato
#property indicator_width1 2
#property indicator_width2 1

input group "══════════ KST参数 (经典马丁·普林设置) ══════════"
input int      InpROC1 = 10;                       // ROC周期1
input int      InpROC2 = 15;                       // ROC周期2
input int      InpROC3 = 20;                       // ROC周期3
input int      InpROC4 = 30;                       // ROC周期4
input int      InpSMA1 = 10;                       // 平滑1
input int      InpSMA2 = 10;                       // 平滑2
input int      InpSMA3 = 10;                       // 平滑3
input int      InpSMA4 = 15;                       // 平滑4
input int      InpSignal = 9;                      // 信号线周期

double KST[], Signal[];

int OnInit() {
   SetIndexBuffer(0, KST);
   SetIndexBuffer(1, Signal);
   
   SetIndexStyle(0, DRAW_LINE);
   SetIndexStyle(1, DRAW_LINE);
   
   SetIndexLabel(0, "KST");
   SetIndexLabel(1, "Signal");
   
   IndicatorShortName("KST");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   int maxROC = MathMax(MathMax(InpROC1, InpROC2), MathMax(InpROC3, InpROC4));
   int maxSMA = MathMax(MathMax(InpSMA1, InpSMA2), MathMax(InpSMA3, InpSMA4));
   int needBars = maxROC + maxSMA + InpSignal + 2;
   
   for(int i = 0; i < rates_total; i++) {
      if(i < needBars) { KST[i] = 0; Signal[i] = 0; continue; }
      
      // 4个ROC分量
      double roc1 = ROC(close, InpROC1, i);
      double roc2 = ROC(close, InpROC2, i);
      double roc3 = ROC(close, InpROC3, i);
      double roc4 = ROC(close, InpROC4, i);
      
      // SMA平滑各分量
      double sma1 = SMAOf(close, roc1, InpSMA1, i);
      double sma2 = SMAOf(close, roc2, InpSMA2, i);
      double sma3 = SMAOf(close, roc3, InpSMA3, i);
      double sma4 = SMAOf(close, roc4, InpSMA4, i);
      
      // 加权和 (Pring经典权重: 1,2,3,4)
      KST[i] = sma1 * 1.0 + sma2 * 2.0 + sma3 * 3.0 + sma4 * 4.0;
      
      // 信号线: KST的SMA
      double sum = 0;
      for(int j = 0; j < InpSignal; j++)
         sum += KST[i - j];
      Signal[i] = sum / InpSignal;
   }
   
   return(rates_total);
}

double ROC(const double &price[], int period, int idx) {
   if(idx < period || price[idx-period] == 0) return 0;
   return (price[idx] - price[idx-period]) / price[idx-period] * 100.0;
}

double SMAOf(const double &price[], double rocVal, int period, int idx) {
   double sum = rocVal;
   int count = 1;
   for(int j = 1; j < period && idx - j >= 0; j++) {
      sum += ROC(price, 1, idx - j) * 100.0;  // 简化
      count++;
   }
   return sum / count;
}
//+------------------------------------------------------------------+
