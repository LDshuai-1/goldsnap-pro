//+------------------------------------------------------------------+
//| VWAP.mq4                                                          |
//| 成交量加权平均价格 - 机构交易员核心参考                              |
//| 用法: 价格>VWAP=买方主导, 价格<VWAP=卖方主导, VWAP本身=日内平衡点    |
//| 重置: 每日/每周自动重置                                            |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 5
#property indicator_color1 clrGold
#property indicator_color2 clrDodgerBlue
#property indicator_color3 clrDodgerBlue
#property indicator_color4 clrTomato
#property indicator_color5 clrTomato
#property indicator_width1 2
#property indicator_width2 1
#property indicator_width3 1
#property indicator_width4 1
#property indicator_width5 1

input group "══════════ VWAP参数 ══════════"
input ENUM_TIMEFRAMES InpResetTF = PERIOD_D1;      // 重置周期(D1=日, W1=周)

double VWAP[], Upper1[], Lower1[], Upper2[], Lower2[];

int OnInit() {
   SetIndexBuffer(0, VWAP);
   SetIndexBuffer(1, Upper1);
   SetIndexBuffer(2, Lower1);
   SetIndexBuffer(3, Upper2);
   SetIndexBuffer(4, Lower2);
   
   SetIndexStyle(0, DRAW_LINE);
   SetIndexStyle(1, DRAW_LINE, STYLE_DOT);
   SetIndexStyle(2, DRAW_LINE, STYLE_DOT);
   SetIndexStyle(3, DRAW_LINE, STYLE_DOT);
   SetIndexStyle(4, DRAW_LINE, STYLE_DOT);
   
   SetIndexLabel(0, "VWAP");
   SetIndexLabel(1, "VWAP +1σ");
   SetIndexLabel(2, "VWAP -1σ");
   SetIndexLabel(3, "VWAP +2σ");
   SetIndexLabel(4, "VWAP -2σ");
   
   IndicatorShortName("VWAP(" + EnumToString(InpResetTF) + ")");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   for(int i = 0; i < rates_total; i++) {
      // 从后往前找这个周期内最近的起点
      double sumPV = 0, sumV = 0, sumP2V = 0;
      int j = i;
      datetime startTime = iTime(NULL, InpResetTF, iBarShift(NULL, InpResetTF, time[i]));
      
      while(j >= 0 && time[j] >= startTime) {
         double typical = (high[j] + low[j] + close[j]) / 3.0;
         double vol = (double)tick_volume[j];
         if(vol <= 0) vol = 1;
         
         sumPV += typical * vol;
         sumV += vol;
         j--;
      }
      
      double vwap = (sumV > 0) ? sumPV / sumV : close[i];
      
      // 计算标准差
      j = i;
      double sumDev = 0;
      while(j >= 0 && time[j] >= startTime) {
         double typical = (high[j] + low[j] + close[j]) / 3.0;
         double vol = (double)tick_volume[j];
         if(vol <= 0) vol = 1;
         double diff = typical - vwap;
         sumDev += diff * diff * vol;
         j--;
      }
      double std = (sumV > 0) ? MathSqrt(sumDev / sumV) : 0;
      
      VWAP[i] = vwap;
      Upper1[i] = vwap + std;
      Lower1[i] = vwap - std;
      Upper2[i] = vwap + 2 * std;
      Lower2[i] = vwap - 2 * std;
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
