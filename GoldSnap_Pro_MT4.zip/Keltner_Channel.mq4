//+------------------------------------------------------------------+
//| Keltner_Channel.mq4                                               |
//| SMA中线 + ATR上下轨 - 替代Bollinger的波动通道                       |
//| 用法: 价格突破上轨=强势, 突破下轨=弱势, 中轨=支撑/阻力             |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 3
#property indicator_color1 clrDodgerBlue
#property indicator_color2 clrOrange
#property indicator_color3 clrYellow
#property indicator_width1 1
#property indicator_width2 1
#property indicator_width3 2

input group "══════════ Keltner参数 ══════════"
input int      InpMAPeriod = 20;                   // MA周期
input int      InpATRPeriod = 14;                  // ATR周期
input double   InpATRMult = 2.0;                   // ATR倍数
input ENUM_MA_METHOD InpMAMethod = MODE_SMA;       // MA类型

double Upper[], Middle[], Lower[];

int OnInit() {
   SetIndexBuffer(0, Upper);
   SetIndexBuffer(1, Middle);
   SetIndexBuffer(2, Lower);
   
   SetIndexStyle(0, DRAW_LINE);
   SetIndexStyle(1, DRAW_LINE);
   SetIndexStyle(2, DRAW_LINE);
   
   SetIndexLabel(0, "KC Upper");
   SetIndexLabel(1, "KC Middle");
   SetIndexLabel(2, "KC Lower");
   
   IndicatorShortName("Keltner(" + IntegerToString(InpMAPeriod) + "," + IntegerToString(InpATRPeriod) + "," + DoubleToString(InpATRMult,1) + ")");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   for(int i = 0; i < rates_total; i++) {
      double ma = iMA(NULL, 0, InpMAPeriod, 0, InpMAMethod, PRICE_TYPICAL, i);
      double atr = iATR(NULL, 0, InpATRPeriod, i);
      
      Middle[i] = ma;
      Upper[i] = ma + InpATRMult * atr;
      Lower[i] = ma - InpATRMult * atr;
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
