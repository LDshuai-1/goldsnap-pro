//+------------------------------------------------------------------+
//| SuperTrend.mq4                                                    |
//| 全球最流行趋势跟踪指标 - 基于ATR动态止损                           |
//| 绿线下方=多头趋势, 红线上方=空头趋势, 变色=信号                     |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_color1 clrLime
#property indicator_color2 clrRed
#property indicator_width1 2
#property indicator_width2 2

input group "══════════ SuperTrend参数 ══════════"
input int      InpATRPeriod = 10;                 // ATR周期
input double   InpMultiplier = 3.0;               // ATR倍数

double UpBuf[], DownBuf[];

int OnInit() {
   SetIndexBuffer(0, UpBuf);
   SetIndexBuffer(1, DownBuf);
   
   SetIndexStyle(0, DRAW_LINE);
   SetIndexStyle(1, DRAW_LINE);
   
   SetIndexLabel(0, "SuperTrend Up");
   SetIndexLabel(1, "SuperTrend Down");
   
   IndicatorShortName("SuperTrend(" + IntegerToString(InpATRPeriod) + "," + DoubleToString(InpMultiplier,1) + ")");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   if(rates_total < InpATRPeriod + 3) return(0);
   
   int limit = rates_total - prev_calculated;
   if(prev_calculated > 0) limit++;
   
   for(int i = MathMax(InpATRPeriod, rates_total - limit); i < rates_total; i++) {
      double atr = iATR(NULL, 0, InpATRPeriod, i);
      double hl2 = (high[i] + low[i]) / 2.0;
      
      double basicUpper = hl2 + InpMultiplier * atr;
      double basicLower = hl2 - InpMultiplier * atr;
      
      double finalUpper = basicUpper;
      double finalLower = basicLower;
      
      if(i > InpATRPeriod) {
         if(basicUpper < UpBuf[i-1] || close[i-1] > UpBuf[i-1])
            finalUpper = basicUpper;
         else
            finalUpper = UpBuf[i-1];
            
         if(basicLower > DownBuf[i-1] || close[i-1] < DownBuf[i-1])
            finalLower = basicLower;
         else
            finalLower = DownBuf[i-1];
      }
      
      // 趋势方向判定
      if(i == InpATRPeriod) {
         if(close[i] > (basicUpper + basicLower) / 2) {
            UpBuf[i] = finalLower;
            DownBuf[i] = EMPTY_VALUE;
         } else {
            DownBuf[i] = finalUpper;
            UpBuf[i] = EMPTY_VALUE;
         }
      } else {
         if(DownBuf[i-1] != EMPTY_VALUE && close[i-1] > DownBuf[i-1]) {
            UpBuf[i] = finalLower;
            DownBuf[i] = EMPTY_VALUE;
         } else if(UpBuf[i-1] != EMPTY_VALUE && close[i-1] < UpBuf[i-1]) {
            DownBuf[i] = finalUpper;
            UpBuf[i] = EMPTY_VALUE;
         } else {
            UpBuf[i] = UpBuf[i-1];
            DownBuf[i] = DownBuf[i-1];
         }
      }
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
