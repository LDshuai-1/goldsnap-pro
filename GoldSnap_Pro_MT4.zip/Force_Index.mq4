//+------------------------------------------------------------------+
//| Force_Index.mq4                                                   |
//| Elder's Force Index - 量×价变化, 测量买卖力量                       |
//| 用法: >0=买方力量, <0=卖方力量, 极值=反转信号, 零轴穿越=趋势确认     |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_separate_window
#property indicator_buffers 2
#property indicator_color1 clrLime
#property indicator_color2 clrRed
#property indicator_width1 3
#property indicator_width2 3

input group "══════════ Force Index参数 ══════════"
input int      InpMAPeriod = 13;                   // 平滑周期
input ENUM_MA_METHOD InpMAMethod = MODE_EMA;       // 平滑方式

double ForceBuf[], SignalBuf[];

int OnInit() {
   SetIndexBuffer(0, ForceBuf);
   SetIndexBuffer(1, SignalBuf);
   
   SetIndexStyle(0, DRAW_HISTOGRAM);
   SetIndexStyle(1, DRAW_LINE);
   
   SetIndexLabel(0, "Force(" + IntegerToString(InpMAPeriod) + ")");
   SetIndexLabel(1, "Zero");
   
   IndicatorShortName("Force Index(" + IntegerToString(InpMAPeriod) + ")");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   for(int i = 0; i < rates_total; i++) {
      SignalBuf[i] = 0;
      
      if(i < 1) { ForceBuf[i] = 0; continue; }
      
      double vol = (double)tick_volume[i];
      if(vol <= 0) vol = 1;
      
      // 原始Force = 成交量 × (当前收盘 - 前收盘)
      double rawForce = vol * (close[i] - close[i-1]);
      
      if(i < InpMAPeriod) {
         ForceBuf[i] = rawForce;
      } else {
         ForceBuf[i] = iMAOnArray(rawForce, 1, InpMAPeriod, 0, InpMAMethod, i);
      }
   }
   
   return(rates_total);
}

// 辅助: 对单个值数组做MA
double iMAOnArray(double value, int offset, int period, int shift, int method, int idx) {
   // 简化实现: 直接调用MT4 MA
   double buf[];
   ArrayResize(buf, idx + 1);
   for(int i = 0; i <= idx; i++) {
      double vol = (double)iVolume(NULL, 0, i);
      if(vol <= 0) vol = 1;
      buf[i] = vol * (iClose(NULL,0,i) - iClose(NULL,0,i+1));
   }
   double ma = iMAOnArray(buf, 0, period, shift, method, idx);
   ArrayFree(buf);
   return ma;
}
//+------------------------------------------------------------------+
