//+------------------------------------------------------------------+
//| Heikin_Ashi.mq4                                                   |
//| 平滑蜡烛图 - 滤除噪音, 趋势更清晰                                   |
//| 用法: 连续阳线=上升趋势, 连续阴线=下降趋势, 无影线=强趋势           |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 4
#property indicator_color1 clrLime
#property indicator_color2 clrRed
#property indicator_color3 clrLime
#property indicator_color4 clrRed
#property indicator_width1 1
#property indicator_width2 1
#property indicator_width3 1
#property indicator_width4 1

double HAOpen[], HAClose[], HAHigh[], HALow[];

int OnInit() {
   SetIndexBuffer(0, HAOpen);
   SetIndexBuffer(1, HAClose);
   SetIndexBuffer(2, HAHigh);
   SetIndexBuffer(3, HALow);
   
   SetIndexStyle(0, DRAW_HISTOGRAM);
   SetIndexStyle(1, DRAW_HISTOGRAM);
   SetIndexStyle(2, DRAW_HISTOGRAM);
   SetIndexStyle(3, DRAW_HISTOGRAM);
   
   IndicatorShortName("Heikin Ashi");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   int start = (prev_calculated > 0) ? prev_calculated - 1 : 1;
   
   for(int i = start; i < rates_total; i++) {
      double haClose = (open[i] + high[i] + low[i] + close[i]) / 4.0;
      
      double haOpen;
      if(i > 0)
         haOpen = (HAOpen[i-1] + HAClose[i-1]) / 2.0;
      else
         haOpen = (open[i] + close[i]) / 2.0;
      
      double haHigh = MathMax(high[i], MathMax(haOpen, haClose));
      double haLow = MathMin(low[i], MathMin(haOpen, haClose));
      
      HAOpen[i] = haOpen;
      HAClose[i] = haClose;
      HAHigh[i] = haHigh;
      HALow[i] = haLow;
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
