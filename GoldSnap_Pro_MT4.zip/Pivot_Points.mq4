//+------------------------------------------------------------------+
//| Pivot_Points.mq4                                                  |
//| 经典场内交易员支撑阻力 - 基于昨日/上周高低收计算                      |
//| 用法: R1/R2/R3=阻力, S1/S2/S3=支撑, PP=中枢                        |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 7
#property indicator_color1 clrGold
#property indicator_color2 clrTomato
#property indicator_color3 clrTomato
#property indicator_color4 clrTomato
#property indicator_color5 clrDodgerBlue
#property indicator_color6 clrDodgerBlue
#property indicator_color7 clrDodgerBlue
#property indicator_width1 2
#property indicator_width2 1
#property indicator_width3 1
#property indicator_width4 1
#property indicator_width5 1
#property indicator_width6 1
#property indicator_width7 1

double PP[], R1[], R2[], R3[], S1[], S2[], S3[];

int OnInit() {
   SetIndexBuffer(0, PP);
   SetIndexBuffer(1, R1);
   SetIndexBuffer(2, R2);
   SetIndexBuffer(3, R3);
   SetIndexBuffer(4, S1);
   SetIndexBuffer(5, S2);
   SetIndexBuffer(6, S3);
   
   for(int i = 0; i < 7; i++) {
      SetIndexStyle(i, DRAW_LINE);
      SetIndexShift(i, 0);
   }
   
   SetIndexLabel(0, "PP");
   SetIndexLabel(1, "R1");
   SetIndexLabel(2, "R2");
   SetIndexLabel(3, "R3");
   SetIndexLabel(4, "S1");
   SetIndexLabel(5, "S2");
   SetIndexLabel(6, "S3");
   
   IndicatorShortName("Pivot Points (Daily)");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   for(int i = 0; i < rates_total; i++) {
      // 找到昨天的K线索引
      datetime curDayStart = iTime(NULL, PERIOD_D1, iBarShift(NULL, PERIOD_D1, time[i]));
      int yesterdayIdx = iBarShift(NULL, PERIOD_D1, curDayStart) + 1;
      
      double prevH = iHigh(NULL, PERIOD_D1, yesterdayIdx);
      double prevL = iLow(NULL, PERIOD_D1, yesterdayIdx);
      double prevC = iClose(NULL, PERIOD_D1, yesterdayIdx);
      
      if(prevH <= 0 || prevL <= 0 || prevC <= 0) {
         PP[i] = 0; R1[i] = 0; R2[i] = 0; R3[i] = 0;
         S1[i] = 0; S2[i] = 0; S3[i] = 0;
         continue;
      }
      
      double pp = (prevH + prevL + prevC) / 3.0;
      double r1 = 2 * pp - prevL;
      double s1 = 2 * pp - prevH;
      double r2 = pp + (prevH - prevL);
      double s2 = pp - (prevH - prevL);
      double r3 = prevH + 2 * (pp - prevL);
      double s3 = prevL - 2 * (prevH - pp);
      
      PP[i] = pp;
      R1[i] = r1; R2[i] = r2; R3[i] = r3;
      S1[i] = s1; S2[i] = s2; S3[i] = s3;
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
