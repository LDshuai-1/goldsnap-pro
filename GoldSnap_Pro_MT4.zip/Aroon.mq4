//+------------------------------------------------------------------+
//| Aroon.mq4                                                         |
//| 趋势强度指标 - 测量新高/新低距当前的时间                            |
//| 用法: AroonUp>70且AroonDown<30=强上升, 反之强下降, 交叉=转势        |
//+------------------------------------------------------------------+
#property copyright "Hermes Research"
#property version   "1.00"
#property strict
#property indicator_separate_window
#property indicator_buffers 3
#property indicator_color1 clrDodgerBlue
#property indicator_color2 clrTomato
#property indicator_color3 clrGray
#property indicator_width1 2
#property indicator_width2 2
#property indicator_width3 1
#property indicator_minimum 0
#property indicator_maximum 100

input int InpAroonPeriod = 25;                     // Aroon周期

double AroonUp[], AroonDown[], Lvl50[];

int OnInit() {
   SetIndexBuffer(0, AroonUp);
   SetIndexBuffer(1, AroonDown);
   SetIndexBuffer(2, Lvl50);
   
   SetIndexStyle(0, DRAW_LINE);
   SetIndexStyle(1, DRAW_LINE);
   SetIndexStyle(2, DRAW_LINE);
   
   SetIndexLabel(0, "Aroon Up");
   SetIndexLabel(1, "Aroon Down");
   SetIndexLabel(2, "50");
   
   IndicatorShortName("Aroon(" + IntegerToString(InpAroonPeriod) + ")");
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[],
                const double &high[], const double &low[],
                const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[]) {
   
   for(int i = 0; i < rates_total; i++) {
      Lvl50[i] = 50;
      
      int lookback = MathMin(InpAroonPeriod, i);
      if(lookback <= 0) { AroonUp[i] = 50; AroonDown[i] = 50; continue; }
      
      int highestIdx = iHighest(NULL, 0, MODE_HIGH, lookback + 1, i - lookback);
      int lowestIdx  = iLowest(NULL, 0, MODE_LOW, lookback + 1, i - lookback);
      
      int barsSinceHigh = i - (i - lookback + highestIdx);
      int barsSinceLow  = i - (i - lookback + lowestIdx);
      
      AroonUp[i]   = 100.0 * (InpAroonPeriod - barsSinceHigh) / InpAroonPeriod;
      AroonDown[i] = 100.0 * (InpAroonPeriod - barsSinceLow) / InpAroonPeriod;
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
